# Part B2: CORe50 ten_categories_resnet18_stride5 (test sessions 3, 7, 10)

**Status:** Measured on CORe50; hyperparameters selected on validation session only

## Protocol

- protocol: ten_categories
- encoder: resnet18
- train_sessions: [1, 2, 4, 5, 6, 8, 9]
- val_sessions: [11]
- test_sessions: [3, 7, 10]
- frame_stride: 5
- max_frames: 60
- hflip_tta: True
- batch_size: 64
- num_workers: 2
- seeds: [11, 22, 33, 44, 55]
- tune_seeds: [11, 22, 33]
- stages: ((1, 6), (11, 16), (21, 26), (31, 36), (41, 46))
- tuned_v2: {'vpl': 'whiten', 'sigma_scale': 0.9, 'target_node_fraction': 0.02, 'rk': (0.5, 0.95, 0.5), 'merge_thr': 0.2, 'join_thr': 0.5, 'anchor': 0.2}
- tuned_v3: {'tau_stm': 0.5, 'merge_ep': 0.45, 'w_ep': 0.75, 'ep_sigma_scale': 0.5, 'tau_match': 0.7, 'margin': 0.1, 'join_ep': 0.7}
- v1_node_fraction: 0.01
- hyperparameters: {'sigma_scale': 0.9, 'target_node_fraction': 0.02, 'merge_thr': 0.2, 'join_thr': 0.5, 'tau_stm': 0.5, 'merge_ep': 0.45, 'w_ep': 0.75, 'ep_sigma_scale': 0.5, 'tau_match': 0.7, 'margin': 0.1, 'join_ep': 0.7}

## Final results (mean over runs)

| Variant | ACC | BWT | Forgetting | RET_ACC | RET_Forgetting | AUC_matched | ARI_seen | NMI_seen | HungarianAcc | legacy_group_ARI | prototypes | concepts | memory_floats |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A  v1 Baseline (original) | 0.274 | -0.003 | 0.006 | 0.174 | 0.000 | 0.259 | 0.283 | 0.643 | 0.334 | 0.185 | 585.800 | 585.800 | 301101.200 |
| A* v1 Baseline (tuned budget) | 0.479 | -0.141 | 0.182 | 0.351 | 0.149 | 0.527 | 0.350 | 0.550 | 0.503 | 0.382 | 27.200 | 27.200 | 13980.800 |
| B  v1 + Stability | 0.558 | -0.196 | 0.201 | 0.418 | 0.122 | 0.634 | 0.486 | 0.652 | 0.578 | 0.636 | 16.600 | 16.600 | 8532.400 |
| C  + VPL | 0.425 | -0.210 | 0.224 | 0.394 | 0.194 | 0.443 | 0.366 | 0.531 | 0.444 | 0.570 | 10.200 | 10.200 | 1326.000 |
| D  + RKLL two-timescale recurrence | 0.711 | -0.023 | 0.023 | 0.661 | 0.007 | 0.540 | 0.793 | 0.903 | 0.764 | 0.829 | 26.000 | 26.000 | 6708.000 |
| E  + EMCL anchors | 0.752 | -0.020 | 0.020 | 0.702 | 0.011 | 0.572 | 0.837 | 0.913 | 0.817 | 0.802 | 27.200 | 27.200 | 7017.600 |
| F  RKEM-Net v2 (full) | 0.733 | -0.019 | 0.019 | 0.706 | 0.011 | 0.527 | 0.836 | 0.912 | 0.817 | 0.802 | 27.200 | 25.600 | 7017.600 |
| G  v2 + generative replay | 0.733 | -0.019 | 0.020 | 0.708 | 0.011 | 0.527 | 0.836 | 0.912 | 0.817 | 0.802 | 27.200 | 25.600 | 7017.600 |
| L1 v2 - VPL | 0.424 | -0.001 | 0.001 | 0.269 | 0.000 | 0.431 | 0.599 | 0.805 | 0.585 | 0.463 | 88.800 | 61.200 | 91108.800 |
| L2 v2 - recurrence | 0.206 | -0.113 | 0.123 | 0.184 | 0.080 | 0.340 | 0.067 | 0.157 | 0.224 | 0.139 | 10.400 | 6.600 | 1352.000 |
| L3 v2 - anchors | 0.696 | -0.015 | 0.022 | 0.663 | 0.007 | 0.498 | 0.793 | 0.903 | 0.764 | 0.829 | 26.000 | 24.600 | 6708.000 |
| L4 v2 - concepts | 0.752 | -0.020 | 0.020 | 0.702 | 0.011 | 0.572 | 0.837 | 0.913 | 0.817 | 0.802 | 27.200 | 27.200 | 7017.600 |
| C1 v2 shuffled frames | 0.710 | -0.025 | 0.026 | 0.583 | 0.015 | 0.563 | 0.765 | 0.880 | 0.768 | 0.753 | 32.600 | 29.000 | 8410.800 |
| C2 v2 task-free (no boundaries) | 0.463 | -0.039 | 0.042 | 0.500 | 0.000 | 0.472 | 0.453 | 0.620 | 0.465 | 0.045 | 20.200 | 5.000 | 5211.600 |
| V3  RKEM-Net v3 (full) | 0.819 | 0.016 | 0.001 | 0.771 | 0.000 | 0.642 | 0.891 | 0.948 | 0.859 | 0.806 | 29.400 | 7.600 | 25545.800 |
| V3a v3 frame-level routing | 0.839 | 0.016 | 0.000 | 0.786 | 0.000 | 0.651 | 0.912 | 0.955 | 0.879 | 0.847 | 32.200 | 8.000 | 26265.400 |
| V3b v3 no margin gate | 0.819 | 0.016 | 0.001 | 0.771 | 0.000 | 0.642 | 0.891 | 0.948 | 0.859 | 0.806 | 29.400 | 7.600 | 25545.800 |
| V3c v3 no STM (ambiguous->LTM) | 0.260 | -0.058 | 0.075 | 0.223 | 0.064 | 0.374 | 0.269 | 0.626 | 0.300 | 0.562 | 27.400 | 2.000 | 18658.200 |
| V3d v3 no episode keys (w_ep=0) | 0.495 | -0.005 | 0.005 | 0.495 | 0.001 | 0.497 | 0.508 | 0.767 | 0.498 | 0.399 | 27.800 | 5.000 | 22564.600 |
| V3e v3 unlimited memory | 0.819 | 0.016 | 0.001 | 0.771 | 0.000 | 0.642 | 0.891 | 0.948 | 0.859 | 0.806 | 29.400 | 7.600 | 25545.800 |
| V3f v3 shuffled frames | 0.810 | -0.003 | 0.004 | 0.783 | 0.000 | 0.625 | 0.871 | 0.927 | 0.869 | 0.803 | 35.600 | 8.000 | 27139.200 |
| V3g v3 task-free (no boundaries) | 0.129 | -0.181 | 0.186 | 0.300 | 0.000 | 0.265 | 0.006 | 0.064 | 0.130 | 0.028 | 13.000 | 2.000 | 4626.000 |
| V31 v3.1 detector also inside given recordings | 0.780 | 0.003 | 0.007 | 0.767 | 0.002 | 0.558 | 0.860 | 0.890 | 0.831 | 0.785 | 64.000 | 33.600 | 55100.800 |
| V31f v3.1 shuffled frames | 0.674 | -0.004 | 0.004 | 0.618 | 0.004 | 0.457 | 0.731 | 0.788 | 0.707 | 0.611 | 222.000 | 222.000 | 346436.000 |
| V31g v3.1 task-free (no boundaries) | 0.781 | 0.004 | 0.011 | 0.786 | 0.000 | 0.558 | 0.861 | 0.891 | 0.831 | 0.786 | 64.000 | 33.200 | 52222.400 |

## Paired comparison vs tuned v1 baseline (stage-mean matched accuracy)

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.2675 |    0.0715 |      0 |   5 |       0.0625 |
| B  v1 + Stability                              |      0.1072 |    0.0513 |      5 |   5 |       0.0625 |
| C  + VPL                                       |     -0.0841 |    0.0679 |      1 |   5 |       0.125  |
| C1 v2 shuffled frames                          |      0.0359 |    0.0863 |      4 |   5 |       0.625  |
| C2 v2 task-free (no boundaries)                |     -0.0545 |    0.0414 |      1 |   5 |       0.125  |
| D  + RKLL two-timescale recurrence             |      0.013  |    0.0822 |      2 |   5 |       1      |
| E  + EMCL anchors                              |      0.0455 |    0.1114 |      4 |   5 |       0.4375 |
| F  RKEM-Net v2 (full)                          |     -0      |    0.1106 |      3 |   5 |       1      |
| G  v2 + generative replay                      |      0.0001 |    0.11   |      3 |   5 |       1      |
| L1 v2 - VPL                                    |     -0.0958 |    0.1476 |      2 |   5 |       0.3125 |
| L2 v2 - recurrence                             |     -0.1873 |    0.0849 |      0 |   5 |       0.0625 |
| L3 v2 - anchors                                |     -0.0286 |    0.0774 |      2 |   5 |       0.4375 |
| L4 v2 - concepts                               |      0.0455 |    0.1114 |      4 |   5 |       0.4375 |
| V3  RKEM-Net v3 (full)                         |      0.1148 |    0.0863 |      4 |   5 |       0.125  |
| V31 v3.1 detector also inside given recordings |      0.0315 |    0.0496 |      4 |   5 |       0.1875 |
| V31f v3.1 shuffled frames                      |     -0.0699 |    0.0492 |      0 |   5 |       0.0625 |
| V31g v3.1 task-free (no boundaries)            |      0.0308 |    0.0469 |      4 |   5 |       0.3125 |
| V3a v3 frame-level routing                     |      0.124  |    0.1002 |      4 |   5 |       0.125  |
| V3b v3 no margin gate                          |      0.1148 |    0.0863 |      4 |   5 |       0.125  |
| V3c v3 no STM (ambiguous->LTM)                 |     -0.1531 |    0.0949 |      0 |   5 |       0.0625 |
| V3d v3 no episode keys (w_ep=0)                |     -0.0299 |    0.0399 |      1 |   5 |       0.1875 |
| V3e v3 unlimited memory                        |      0.1148 |    0.0863 |      4 |   5 |       0.125  |
| V3f v3 shuffled frames                         |      0.0984 |    0.1187 |      4 |   5 |       0.1875 |
| V3g v3 task-free (no boundaries)               |     -0.262  |    0.0461 |      0 |   5 |       0.0625 |

## Ablation: paired difference vs full v2 (negative = component helps)

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.2674 |    0.1135 |      0 |   5 |       0.0625 |
| A* v1 Baseline (tuned budget)                  |      0      |    0.1106 |      2 |   5 |       1      |
| B  v1 + Stability                              |      0.1072 |    0.0881 |      5 |   5 |       0.0625 |
| C  + VPL                                       |     -0.0841 |    0.1514 |      1 |   5 |       0.3125 |
| C1 v2 shuffled frames                          |      0.0359 |    0.14   |      3 |   5 |       0.8125 |
| C2 v2 task-free (no boundaries)                |     -0.0545 |    0.0972 |      1 |   5 |       0.4375 |
| D  + RKLL two-timescale recurrence             |      0.013  |    0.0547 |      2 |   5 |       0.8125 |
| E  + EMCL anchors                              |      0.0455 |    0.0342 |      5 |   5 |       0.0625 |
| G  v2 + generative replay                      |      0.0001 |    0.0006 |      3 |   5 |       1      |
| L1 v2 - VPL                                    |     -0.0957 |    0.2207 |      2 |   5 |       0.625  |
| L2 v2 - recurrence                             |     -0.1873 |    0.1393 |      1 |   5 |       0.125  |
| L3 v2 - anchors                                |     -0.0286 |    0.0421 |      1 |   5 |       0.3125 |
| L4 v2 - concepts                               |      0.0455 |    0.0342 |      5 |   5 |       0.0625 |
| V3  RKEM-Net v3 (full)                         |      0.1148 |    0.0742 |      5 |   5 |       0.0625 |
| V31 v3.1 detector also inside given recordings |      0.0315 |    0.1149 |      2 |   5 |       1      |
| V31f v3.1 shuffled frames                      |     -0.0698 |    0.0947 |      1 |   5 |       0.3125 |
| V31g v3.1 task-free (no boundaries)            |      0.0308 |    0.1144 |      3 |   5 |       1      |
| V3a v3 frame-level routing                     |      0.124  |    0.0678 |      5 |   5 |       0.0625 |
| V3b v3 no margin gate                          |      0.1148 |    0.0742 |      5 |   5 |       0.0625 |
| V3c v3 no STM (ambiguous->LTM)                 |     -0.1531 |    0.0837 |      0 |   5 |       0.0625 |
| V3d v3 no episode keys (w_ep=0)                |     -0.0298 |    0.0966 |      1 |   5 |       0.625  |
| V3e v3 unlimited memory                        |      0.1148 |    0.0742 |      5 |   5 |       0.0625 |
| V3f v3 shuffled frames                         |      0.0985 |    0.0816 |      4 |   5 |       0.125  |
| V3g v3 task-free (no boundaries)               |     -0.262  |    0.0985 |      0 |   5 |       0.0625 |

## v3_vs_v2_all_metrics

|                                           |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| ('AUC_matched', 'V3  RKEM-Net v3 (full)') |      0.1148 |    0.0742 |      5 |   5 |       0.0625 |
| ('ARI_seen', 'V3  RKEM-Net v3 (full)')    |      0.0554 |    0.0877 |      4 |   5 |       0.3125 |
| ('RET_ACC', 'V3  RKEM-Net v3 (full)')     |      0.0652 |    0.0945 |      4 |   5 |       0.3125 |
| ('RET_F', 'V3  RKEM-Net v3 (full)')       |     -0.0107 |    0.0159 |      1 |   5 |       0.25   |
| ('BWT', 'V3  RKEM-Net v3 (full)')         |      0.0349 |    0.0385 |      3 |   5 |       0.3125 |

## v3_ablations

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.3822 |    0.0606 |      0 |   5 |       0.0625 |
| A* v1 Baseline (tuned budget)                  |     -0.1148 |    0.0863 |      1 |   5 |       0.125  |
| B  v1 + Stability                              |     -0.0076 |    0.0524 |      2 |   5 |       1      |
| C  + VPL                                       |     -0.1989 |    0.1184 |      0 |   5 |       0.0625 |
| C1 v2 shuffled frames                          |     -0.0789 |    0.1384 |      1 |   5 |       0.3125 |
| C2 v2 task-free (no boundaries)                |     -0.1693 |    0.0644 |      0 |   5 |       0.0625 |
| D  + RKLL two-timescale recurrence             |     -0.1018 |    0.0515 |      0 |   5 |       0.0625 |
| E  + EMCL anchors                              |     -0.0693 |    0.0864 |      2 |   5 |       0.3125 |
| F  RKEM-Net v2 (full)                          |     -0.1148 |    0.0742 |      0 |   5 |       0.0625 |
| G  v2 + generative replay                      |     -0.1147 |    0.0739 |      0 |   5 |       0.0625 |
| L1 v2 - VPL                                    |     -0.2105 |    0.1604 |      1 |   5 |       0.125  |
| L2 v2 - recurrence                             |     -0.302  |    0.0826 |      0 |   5 |       0.0625 |
| L3 v2 - anchors                                |     -0.1434 |    0.038  |      0 |   5 |       0.0625 |
| L4 v2 - concepts                               |     -0.0693 |    0.0864 |      2 |   5 |       0.3125 |
| V31 v3.1 detector also inside given recordings |     -0.0832 |    0.0709 |      1 |   5 |       0.125  |
| V31f v3.1 shuffled frames                      |     -0.1846 |    0.0491 |      0 |   5 |       0.0625 |
| V31g v3.1 task-free (no boundaries)            |     -0.084  |    0.0731 |      1 |   5 |       0.125  |
| V3a v3 frame-level routing                     |      0.0093 |    0.0205 |      2 |   5 |       0.5    |
| V3b v3 no margin gate                          |      0      |    0      |      0 |   5 |       1      |
| V3c v3 no STM (ambiguous->LTM)                 |     -0.2679 |    0.0246 |      0 |   5 |       0.0625 |
| V3d v3 no episode keys (w_ep=0)                |     -0.1446 |    0.0633 |      0 |   5 |       0.0625 |
| V3e v3 unlimited memory                        |      0      |    0      |      0 |   5 |       1      |
| V3f v3 shuffled frames                         |     -0.0163 |    0.0324 |      2 |   5 |       0.4375 |
| V3g v3 task-free (no boundaries)               |     -0.3768 |    0.0606 |      0 |   5 |       0.0625 |

## retention_forgetting_vs_v1

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.1493 |    0.0792 |      0 |   5 |       0.0625 |
| B  v1 + Stability                              |     -0.0273 |    0.0986 |      2 |   5 |       0.4375 |
| C  + VPL                                       |      0.0442 |    0.0608 |      3 |   5 |       0.3125 |
| C1 v2 shuffled frames                          |     -0.1347 |    0.0699 |      0 |   5 |       0.0625 |
| C2 v2 task-free (no boundaries)                |     -0.1494 |    0.0794 |      0 |   5 |       0.0625 |
| D  + RKLL two-timescale recurrence             |     -0.1419 |    0.0662 |      0 |   5 |       0.0625 |
| E  + EMCL anchors                              |     -0.1387 |    0.0727 |      0 |   5 |       0.0625 |
| F  RKEM-Net v2 (full)                          |     -0.1387 |    0.0727 |      0 |   5 |       0.0625 |
| G  v2 + generative replay                      |     -0.1387 |    0.0729 |      0 |   5 |       0.0625 |
| L1 v2 - VPL                                    |     -0.1494 |    0.0794 |      0 |   5 |       0.0625 |
| L2 v2 - recurrence                             |     -0.0689 |    0.079  |      1 |   5 |       0.1875 |
| L3 v2 - anchors                                |     -0.1419 |    0.0662 |      0 |   5 |       0.0625 |
| L4 v2 - concepts                               |     -0.1387 |    0.0727 |      0 |   5 |       0.0625 |
| V3  RKEM-Net v3 (full)                         |     -0.1494 |    0.0794 |      0 |   5 |       0.0625 |
| V31 v3.1 detector also inside given recordings |     -0.1472 |    0.0788 |      0 |   5 |       0.0625 |
| V31f v3.1 shuffled frames                      |     -0.1453 |    0.0815 |      0 |   5 |       0.0625 |
| V31g v3.1 task-free (no boundaries)            |     -0.1492 |    0.0794 |      0 |   5 |       0.0625 |
| V3a v3 frame-level routing                     |     -0.1494 |    0.0794 |      0 |   5 |       0.0625 |
| V3b v3 no margin gate                          |     -0.1494 |    0.0794 |      0 |   5 |       0.0625 |
| V3c v3 no STM (ambiguous->LTM)                 |     -0.0851 |    0.1096 |      1 |   5 |       0.1875 |
| V3d v3 no episode keys (w_ep=0)                |     -0.1488 |    0.0794 |      0 |   5 |       0.0625 |
| V3e v3 unlimited memory                        |     -0.1494 |    0.0794 |      0 |   5 |       0.0625 |
| V3f v3 shuffled frames                         |     -0.1494 |    0.0794 |      0 |   5 |       0.0625 |
| V3g v3 task-free (no boundaries)               |     -0.1492 |    0.0795 |      0 |   5 |       0.0625 |

## Offline (non-continual) reference

| features   |   ARI_seen |   NMI_seen |   HungarianAcc_seen |   MatchedAcc_seen |   ProbeAcc_seen |   supervised_1NN_acc |
|:-----------|-----------:|-----------:|--------------------:|------------------:|----------------:|---------------------:|
| none       |      0.572 |      0.688 |               0.62  |             0.615 |           0.615 |                0.933 |
| center     |      0.543 |      0.678 |               0.627 |             0.619 |           0.608 |                0.933 |
| whiten     |      0.557 |      0.764 |               0.759 |             0.756 |           0.759 |                0.911 |

## Metric definitions

- ARI/NMI_seen: partition agreement on test frames of ALL objects seen so far (detects cross-group interference).
- Matched accuracy: one-to-one cluster->object map fitted on TRAINING assignments (Hungarian), applied to test.
- ACC/BWT/Forgetting: from the matched-accuracy matrix R[stage, group] (Lopez-Paz & Ranzato, 2017).
- RET_ACC/RET_Forgetting: same matched map applied to the already-seen TRAINING frames of each group. This isolates forgetting (overwriting/competition) from cross-session generalisation.
- memory_floats: stored numbers (prototypes + counts + episode keys).
- legacy_group_ARI: the v1 protocol (ARI inside each two-object group); kept for comparability only.

## Limitations to disclose

- Frozen encoder: forgetting is measured in the prototype/concept layer.
- The five orders share the same images (recording order randomised).
- Task-free controls concatenate recordings; real streams may have softer boundaries.
- Matched/probe maps use training labels after learning, for evaluation only.
