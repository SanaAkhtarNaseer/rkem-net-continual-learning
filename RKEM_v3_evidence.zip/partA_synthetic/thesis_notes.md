# RKEM-Net — Part A (simulator)

**Status:** Simulator validation, not CORe50 evidence

## Protocol

- datasets: [200, 201, 202, 203, 204]
- orders: [11, 22, 33, 44, 55]
- stages: ((0, 1), (2, 3), (4, 5))
- v2_hyperparameters: {'target_node_fraction': 0.02, 'tau_grid': array([0.05, 0.1 , 0.15, 0.2 , 0.25, 0.3 , 0.35, 0.4 , 0.45, 0.5 , 0.55,
       0.6 , 0.65, 0.7 , 0.75, 0.8 , 0.85, 0.9 , 0.95]), 'sigma_scale': 0.7, 'merge_thr': 0.2, 'join_thr': 0.5, 'vis_weight': 0.0, 'rf_min': 0.6, 'eta0': 0.1, 'lam': 0.05, 'boundary_sim': 0.05, 'vpl': 'whiten', 'af': 0.5, 'as_': 0.9, 'rho': 0.5, 'stable': True, 'adaptive_rf': False, 'anchor': 0.2, 'concepts': True, 'replay': 'none', 'sigma0': 'auto'}
- v3_hyperparameters: {'tau_match': 0.6, 'margin': 0.1, 'tau_stm': 0.2, 'block': 10, 'w_ep': 0.5, 'merge_ep': 0.45, 'join_ep': 0.7, 'min_support': 2, 'max_age': None, 'budget': 64, 'eta_stm': 0.2, 'ep_sigma_scale': 0.5, 'max_keys': 16}

## Final results (mean over runs)

| Variant | ACC | BWT | Forgetting | RET_ACC | RET_Forgetting | AUC_matched | ARI_seen | NMI_seen | HungarianAcc | legacy_group_ARI | prototypes | concepts | memory_floats |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A  v1 Baseline (original) | 0.031 | 0.000 | -0.000 | 0.058 | -0.000 | 0.022 | 0.062 | 0.440 | 0.108 | 0.038 | 246.920 | 246.920 | 32099.600 |
| A* v1 Baseline (tuned budget) | 0.134 | -0.053 | 0.061 | 0.203 | 0.036 | 0.153 | 0.108 | 0.273 | 0.246 | 0.088 | 16.880 | 16.880 | 2194.400 |
| B  v1 + Stability | 0.116 | -0.023 | 0.025 | 0.213 | 0.008 | 0.122 | 0.100 | 0.264 | 0.250 | 0.086 | 14.280 | 14.280 | 1856.400 |
| C  + VPL whitening | 0.445 | -0.040 | 0.040 | 0.458 | 0.004 | 0.288 | 0.431 | 0.551 | 0.540 | 0.428 | 24.640 | 24.640 | 3203.200 |
| D  + RKLL two-timescale recurrence | 0.331 | -0.076 | 0.078 | 0.362 | 0.038 | 0.226 | 0.402 | 0.575 | 0.503 | 0.384 | 29.280 | 29.280 | 7554.240 |
| E  + EMCL anchors | 0.382 | -0.036 | 0.036 | 0.421 | 0.000 | 0.247 | 0.470 | 0.628 | 0.549 | 0.441 | 29.840 | 29.840 | 7698.720 |
| F  RKEM-Net v2 (full) | 0.402 | -0.082 | 0.082 | 0.421 | 0.000 | 0.315 | 0.472 | 0.629 | 0.552 | 0.443 | 29.840 | 28.840 | 7698.720 |
| G  v2 + generative replay | 0.404 | -0.082 | 0.082 | 0.422 | 0.000 | 0.315 | 0.479 | 0.634 | 0.554 | 0.444 | 29.920 | 28.920 | 7719.360 |
| H  v2 + adaptive RF | 0.250 | -0.050 | 0.050 | 0.292 | 0.034 | 0.177 | 0.182 | 0.377 | 0.391 | 0.320 | 35.000 | 31.760 | 9030.000 |
| L1 v2 - VPL (no whitening) | 0.213 | -0.028 | 0.028 | 0.272 | 0.017 | 0.230 | 0.137 | 0.310 | 0.302 | 0.127 | 38.240 | 17.120 | 9865.920 |
| L1b v2 centering instead of whitening | 0.313 | -0.043 | 0.043 | 0.362 | 0.022 | 0.270 | 0.232 | 0.313 | 0.389 | 0.233 | 24.200 | 14.320 | 6243.600 |
| L2 v2 - recurrence | 0.483 | -0.067 | 0.067 | 0.479 | 0.000 | 0.353 | 0.462 | 0.567 | 0.565 | 0.444 | 25.440 | 24.600 | 3307.200 |
| L3 v2 - anchors | 0.351 | -0.122 | 0.124 | 0.362 | 0.038 | 0.294 | 0.404 | 0.576 | 0.506 | 0.385 | 29.280 | 28.280 | 7554.240 |
| L4 v2 - concepts | 0.382 | -0.036 | 0.036 | 0.421 | 0.000 | 0.247 | 0.470 | 0.628 | 0.549 | 0.441 | 29.840 | 29.840 | 7698.720 |
| C1 v2 shuffled frames | 0.232 | -0.057 | 0.057 | 0.286 | 0.000 | 0.151 | 0.439 | 0.620 | 0.489 | 0.363 | 38.160 | 36.000 | 9845.280 |
| C2 v2 task-free (no boundaries) | 0.341 | -0.204 | 0.204 | 0.500 | 0.000 | 0.390 | 0.236 | 0.383 | 0.380 | 0.026 | 34.960 | 3.000 | 9019.680 |
| V3  RKEM-Net v3 (full) | 0.501 | -0.207 | 0.207 | 0.640 | 0.001 | 0.481 | 0.403 | 0.587 | 0.566 | 0.365 | 30.880 | 5.520 | 18730.160 |
| V3a v3 frame-level routing | 0.513 | -0.206 | 0.206 | 0.644 | 0.001 | 0.471 | 0.377 | 0.581 | 0.552 | 0.343 | 32.440 | 5.200 | 19131.080 |
| V3b v3 no margin gate | 0.501 | -0.207 | 0.207 | 0.640 | 0.001 | 0.481 | 0.403 | 0.587 | 0.566 | 0.365 | 30.880 | 5.520 | 18730.160 |
| V3c v3 no STM (ambiguous->LTM) | 0.167 | 0.000 | 0.000 | 0.167 | 0.000 | 0.306 | 0.000 | 0.000 | 0.167 | 0.000 | 28.800 | 1.000 | 11513.600 |
| V3d v3 no episode keys (w_ep=0) | 0.499 | -0.181 | 0.181 | 0.636 | 0.000 | 0.445 | 0.328 | 0.541 | 0.506 | 0.250 | 30.600 | 4.040 | 18658.200 |
| V3e v3 unlimited memory | 0.501 | -0.207 | 0.207 | 0.640 | 0.001 | 0.481 | 0.403 | 0.587 | 0.566 | 0.365 | 30.880 | 5.520 | 18730.160 |
| V3f v3 shuffled frames | 0.474 | -0.222 | 0.222 | 0.608 | 0.000 | 0.461 | 0.374 | 0.580 | 0.546 | 0.351 | 36.160 | 5.200 | 20087.120 |
| V3g v3 task-free (no boundaries) | 0.237 | 0.000 | 0.000 | 0.333 | 0.000 | 0.329 | 0.138 | 0.319 | 0.329 | 0.169 | 25.400 | 1.000 | 7298.800 |
| V31 v3.1 detector also inside given recordings | 0.506 | -0.195 | 0.195 | 0.633 | 0.001 | 0.486 | 0.430 | 0.609 | 0.587 | 0.381 | 25.840 | 5.680 | 17948.880 |
| V31f v3.1 shuffled frames | 0.522 | -0.182 | 0.182 | 0.661 | 0.000 | 0.484 | 0.406 | 0.579 | 0.571 | 0.367 | 21.520 | 6.480 | 31970.800 |
| V31g v3.1 task-free (no boundaries) | 0.506 | -0.195 | 0.195 | 0.633 | 0.001 | 0.486 | 0.430 | 0.609 | 0.587 | 0.381 | 25.840 | 5.680 | 17496.560 |

## Paired comparison vs tuned v1 baseline (stage-mean matched accuracy)

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.1313 |    0.0236 |      0 |  25 |       0      |
| B  v1 + Stability                              |     -0.0314 |    0.0305 |      3 |  25 |       0.0001 |
| C  + VPL whitening                             |      0.1343 |    0.1339 |     19 |  25 |       0.0001 |
| C1 v2 shuffled frames                          |     -0.002  |    0.0552 |     12 |  25 |       0.8823 |
| C2 v2 task-free (no boundaries)                |      0.2362 |    0.0363 |     25 |  25 |       0      |
| D  + RKLL two-timescale recurrence             |      0.0727 |    0.1388 |     16 |  25 |       0.0451 |
| E  + EMCL anchors                              |      0.0936 |    0.1637 |     16 |  25 |       0.0451 |
| F  RKEM-Net v2 (full)                          |      0.1614 |    0.1231 |     21 |  25 |       0      |
| G  v2 + generative replay                      |      0.1618 |    0.1264 |     21 |  25 |       0      |
| H  v2 + adaptive RF                            |      0.0234 |    0.1196 |     13 |  25 |       0.7112 |
| L1 v2 - VPL (no whitening)                     |      0.0767 |    0.0789 |     19 |  25 |       0.0001 |
| L1b v2 centering instead of whitening          |      0.1168 |    0.0672 |     25 |  25 |       0      |
| L2 v2 - recurrence                             |      0.2    |    0.1185 |     24 |  25 |       0      |
| L3 v2 - anchors                                |      0.1405 |    0.1028 |     21 |  25 |       0      |
| L4 v2 - concepts                               |      0.0936 |    0.1637 |     16 |  25 |       0.0451 |
| V3  RKEM-Net v3 (full)                         |      0.3274 |    0.0922 |     25 |  25 |       0      |
| V31 v3.1 detector also inside given recordings |      0.3328 |    0.0802 |     25 |  25 |       0      |
| V31f v3.1 shuffled frames                      |      0.331  |    0.0761 |     25 |  25 |       0      |
| V31g v3.1 task-free (no boundaries)            |      0.3328 |    0.0802 |     25 |  25 |       0      |
| V3a v3 frame-level routing                     |      0.3174 |    0.0837 |     25 |  25 |       0      |
| V3b v3 no margin gate                          |      0.3274 |    0.0922 |     25 |  25 |       0      |
| V3c v3 no STM (ambiguous->LTM)                 |      0.1521 |    0.0275 |     25 |  25 |       0      |
| V3d v3 no episode keys (w_ep=0)                |      0.2919 |    0.0534 |     25 |  25 |       0      |
| V3e v3 unlimited memory                        |      0.3274 |    0.0922 |     25 |  25 |       0      |
| V3f v3 shuffled frames                         |      0.3076 |    0.0744 |     25 |  25 |       0      |
| V3g v3 task-free (no boundaries)               |      0.1756 |    0.0275 |     25 |  25 |       0      |

## Ablation: paired difference vs full v2 (negative = component helps)

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.2928 |    0.1188 |      0 |  25 |       0      |
| A* v1 Baseline (tuned budget)                  |     -0.1614 |    0.1231 |      4 |  25 |       0      |
| B  v1 + Stability                              |     -0.1928 |    0.1118 |      0 |  25 |       0      |
| C  + VPL whitening                             |     -0.0271 |    0.1286 |     10 |  25 |       0.3525 |
| C1 v2 shuffled frames                          |     -0.1634 |    0.1305 |      3 |  25 |       0      |
| C2 v2 task-free (no boundaries)                |      0.0748 |    0.1132 |     19 |  25 |       0.0031 |
| D  + RKLL two-timescale recurrence             |     -0.0888 |    0.0563 |      0 |  25 |       0      |
| E  + EMCL anchors                              |     -0.0678 |    0.0703 |      0 |  25 |       0.0007 |
| G  v2 + generative replay                      |      0.0004 |    0.0104 |      7 |  25 |       0.652  |
| H  v2 + adaptive RF                            |     -0.138  |    0.0744 |      0 |  25 |       0      |
| L1 v2 - VPL (no whitening)                     |     -0.0848 |    0.1282 |      6 |  25 |       0.0051 |
| L1b v2 centering instead of whitening          |     -0.0446 |    0.1148 |     11 |  25 |       0.0957 |
| L2 v2 - recurrence                             |      0.0386 |    0.1412 |     16 |  25 |       0.1014 |
| L3 v2 - anchors                                |     -0.021  |    0.0344 |      0 |  25 |       0.0051 |
| L4 v2 - concepts                               |     -0.0678 |    0.0703 |      0 |  25 |       0.0007 |
| V3  RKEM-Net v3 (full)                         |      0.166  |    0.1095 |     24 |  25 |       0      |
| V31 v3.1 detector also inside given recordings |      0.1714 |    0.1293 |     22 |  25 |       0      |
| V31f v3.1 shuffled frames                      |      0.1695 |    0.1398 |     22 |  25 |       0      |
| V31g v3.1 task-free (no boundaries)            |      0.1714 |    0.1293 |     22 |  25 |       0      |
| V3a v3 frame-level routing                     |      0.156  |    0.1316 |     23 |  25 |       0      |
| V3b v3 no margin gate                          |      0.166  |    0.1095 |     24 |  25 |       0      |
| V3c v3 no STM (ambiguous->LTM)                 |     -0.0093 |    0.1213 |     11 |  25 |       0.874  |
| V3d v3 no episode keys (w_ep=0)                |      0.1305 |    0.1035 |     22 |  25 |       0      |
| V3e v3 unlimited memory                        |      0.166  |    0.1095 |     24 |  25 |       0      |
| V3f v3 shuffled frames                         |      0.1462 |    0.1299 |     22 |  25 |       0      |
| V3g v3 task-free (no boundaries)               |      0.0142 |    0.115  |     13 |  25 |       0.615  |

## v3_vs_v2_all_metrics

|                                           |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| ('AUC_matched', 'V3  RKEM-Net v3 (full)') |      0.166  |    0.1095 |     24 |  25 |       0      |
| ('ARI_seen', 'V3  RKEM-Net v3 (full)')    |     -0.0691 |    0.0863 |      5 |  25 |       0.0002 |
| ('RET_ACC', 'V3  RKEM-Net v3 (full)')     |      0.2193 |    0.166  |     21 |  25 |       0.0001 |
| ('RET_F', 'V3  RKEM-Net v3 (full)')       |      0.0011 |    0.0073 |      1 |  25 |       0.715  |
| ('BWT', 'V3  RKEM-Net v3 (full)')         |     -0.1248 |    0.0482 |      0 |  25 |       0      |

## v3_ablations

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.4587 |    0.0828 |      0 |  25 |       0      |
| A* v1 Baseline (tuned budget)                  |     -0.3274 |    0.0922 |      0 |  25 |       0      |
| B  v1 + Stability                              |     -0.3588 |    0.0902 |      0 |  25 |       0      |
| C  + VPL whitening                             |     -0.1931 |    0.0963 |      1 |  25 |       0      |
| C1 v2 shuffled frames                          |     -0.3294 |    0.1051 |      0 |  25 |       0      |
| C2 v2 task-free (no boundaries)                |     -0.0912 |    0.0713 |      2 |  25 |       0      |
| D  + RKLL two-timescale recurrence             |     -0.2547 |    0.1197 |      1 |  25 |       0      |
| E  + EMCL anchors                              |     -0.2338 |    0.1365 |      1 |  25 |       0      |
| F  RKEM-Net v2 (full)                          |     -0.166  |    0.1095 |      1 |  25 |       0      |
| G  v2 + generative replay                      |     -0.1656 |    0.1119 |      1 |  25 |       0      |
| H  v2 + adaptive RF                            |     -0.304  |    0.1192 |      1 |  25 |       0      |
| L1 v2 - VPL (no whitening)                     |     -0.2507 |    0.1196 |      0 |  25 |       0      |
| L1b v2 centering instead of whitening          |     -0.2106 |    0.103  |      0 |  25 |       0      |
| L2 v2 - recurrence                             |     -0.1274 |    0.0952 |      2 |  25 |       0      |
| L3 v2 - anchors                                |     -0.1869 |    0.1032 |      1 |  25 |       0      |
| L4 v2 - concepts                               |     -0.2338 |    0.1365 |      1 |  25 |       0      |
| V31 v3.1 detector also inside given recordings |      0.0054 |    0.0479 |     15 |  25 |       0.2531 |
| V31f v3.1 shuffled frames                      |      0.0036 |    0.0729 |     13 |  25 |       0.9158 |
| V31g v3.1 task-free (no boundaries)            |      0.0054 |    0.0479 |     15 |  25 |       0.2531 |
| V3a v3 frame-level routing                     |     -0.01   |    0.0611 |     13 |  25 |       0.6528 |
| V3b v3 no margin gate                          |      0      |    0      |      0 |  25 |       1      |
| V3c v3 no STM (ambiguous->LTM)                 |     -0.1753 |    0.076  |      0 |  25 |       0      |
| V3d v3 no episode keys (w_ep=0)                |     -0.0355 |    0.0539 |      7 |  25 |       0.0047 |
| V3e v3 unlimited memory                        |      0      |    0      |      0 |  25 |       1      |
| V3f v3 shuffled frames                         |     -0.0198 |    0.0535 |     10 |  25 |       0.1199 |
| V3g v3 task-free (no boundaries)               |     -0.1518 |    0.0719 |      0 |  25 |       0      |

## retention_forgetting_vs_v1

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.0364 |    0.0305 |      3 |  25 |       0.0001 |
| B  v1 + Stability                              |     -0.0278 |    0.0294 |      6 |  25 |       0.0001 |
| C  + VPL whitening                             |     -0.0323 |    0.0497 |      5 |  25 |       0.0004 |
| C1 v2 shuffled frames                          |     -0.0362 |    0.0304 |      3 |  25 |       0.0001 |
| C2 v2 task-free (no boundaries)                |     -0.0362 |    0.0304 |      3 |  25 |       0.0001 |
| D  + RKLL two-timescale recurrence             |      0.0014 |    0.0793 |      8 |  25 |       0.4237 |
| E  + EMCL anchors                              |     -0.036  |    0.0306 |      3 |  25 |       0.0001 |
| F  RKEM-Net v2 (full)                          |     -0.036  |    0.0306 |      3 |  25 |       0.0001 |
| G  v2 + generative replay                      |     -0.0361 |    0.0302 |      3 |  25 |       0.0001 |
| H  v2 + adaptive RF                            |     -0.0019 |    0.0776 |      8 |  25 |       0.3458 |
| L1 v2 - VPL (no whitening)                     |     -0.0191 |    0.0364 |      9 |  25 |       0.016  |
| L1b v2 centering instead of whitening          |     -0.014  |    0.0326 |      9 |  25 |       0.0626 |
| L2 v2 - recurrence                             |     -0.0362 |    0.0304 |      3 |  25 |       0.0001 |
| L3 v2 - anchors                                |      0.0014 |    0.0793 |      8 |  25 |       0.4237 |
| L4 v2 - concepts                               |     -0.036  |    0.0306 |      3 |  25 |       0.0001 |
| V3  RKEM-Net v3 (full)                         |     -0.0348 |    0.0314 |      4 |  25 |       0.0001 |
| V31 v3.1 detector also inside given recordings |     -0.0348 |    0.0314 |      4 |  25 |       0.0001 |
| V31f v3.1 shuffled frames                      |     -0.0362 |    0.0304 |      3 |  25 |       0.0001 |
| V31g v3.1 task-free (no boundaries)            |     -0.0348 |    0.0314 |      4 |  25 |       0.0001 |
| V3a v3 frame-level routing                     |     -0.0348 |    0.0314 |      4 |  25 |       0.0001 |
| V3b v3 no margin gate                          |     -0.0348 |    0.0314 |      4 |  25 |       0.0001 |
| V3c v3 no STM (ambiguous->LTM)                 |     -0.0362 |    0.0304 |      3 |  25 |       0.0001 |
| V3d v3 no episode keys (w_ep=0)                |     -0.0359 |    0.0299 |      3 |  25 |       0.0001 |
| V3e v3 unlimited memory                        |     -0.0348 |    0.0314 |      4 |  25 |       0.0001 |
| V3f v3 shuffled frames                         |     -0.0362 |    0.0304 |      3 |  25 |       0.0001 |
| V3g v3 task-free (no boundaries)               |     -0.0362 |    0.0304 |      3 |  25 |       0.0001 |

## memory_curve

| budget    |   AUC_matched |   ARI_seen |    ACC |     BWT |   RET_ACC |   RET_F |   prototypes |   memory_floats |
|:----------|--------------:|-----------:|-------:|--------:|----------:|--------:|-------------:|----------------:|
| 8         |        0.5064 |     0.4425 | 0.5362 | -0.2168 |    0.6471 | -0.0064 |       8      |         12678.7 |
| 16        |        0.5213 |     0.4535 | 0.5434 | -0.1886 |    0.6397 |  0      |      16      |         14906   |
| 24        |        0.4992 |     0.4454 | 0.5423 | -0.1801 |    0.6444 |  0      |      23.5333 |         16842.1 |
| 32        |        0.4883 |     0.3992 | 0.5153 | -0.2006 |    0.6397 |  0      |      28.4    |         18092.8 |
| 48        |        0.4869 |     0.394  | 0.5112 | -0.2069 |    0.6397 |  0      |      31.0667 |         18778.1 |
| 64        |        0.4869 |     0.394  | 0.5112 | -0.2069 |    0.6397 |  0      |      31.0667 |         18778.1 |
| unlimited |        0.4869 |     0.394  | 0.5112 | -0.2069 |    0.6397 |  0      |      31.0667 |         18778.1 |

## Offline (non-continual) reference

|   dataset | features   |   ARI_seen |   NMI_seen |   HungarianAcc_seen |   MatchedAcc_seen |   ProbeAcc_seen |   supervised_1NN_acc |
|----------:|:-----------|-----------:|-----------:|--------------------:|------------------:|----------------:|---------------------:|
|       200 | none       |      0.234 |      0.314 |               0.418 |             0.272 |           0.272 |                0.735 |
|       200 | center     |      0.229 |      0.298 |               0.41  |             0.294 |           0.258 |                0.733 |
|       200 | whiten     |      0.49  |      0.671 |               0.632 |             0.628 |           0.668 |                0.813 |
|       201 | none       |      0.143 |      0.273 |               0.35  |             0.194 |           0.321 |                0.814 |
|       201 | center     |      0.217 |      0.296 |               0.407 |             0.295 |           0.316 |                0.795 |
|       201 | whiten     |      0.547 |      0.701 |               0.683 |             0.617 |           0.733 |                0.78  |
|       202 | none       |      0.213 |      0.273 |               0.385 |             0.306 |           0.337 |                0.825 |
|       202 | center     |      0.216 |      0.276 |               0.385 |             0.311 |           0.344 |                0.812 |
|       202 | whiten     |      0.722 |      0.837 |               0.783 |             0.782 |           0.782 |                0.8   |
|       203 | none       |      0.212 |      0.271 |               0.414 |             0.341 |           0.328 |                0.776 |
|       203 | center     |      0.226 |      0.291 |               0.407 |             0.335 |           0.331 |                0.78  |
|       203 | whiten     |      0.377 |      0.575 |               0.545 |             0.531 |           0.572 |                0.884 |
|       204 | none       |      0.222 |      0.286 |               0.411 |             0.293 |           0.316 |                0.795 |
|       204 | center     |      0.222 |      0.284 |               0.411 |             0.292 |           0.315 |                0.792 |
|       204 | whiten     |      0.481 |      0.699 |               0.677 |             0.677 |           0.689 |                0.906 |

## Metric definitions

- ARI/NMI_seen: partition agreement on test frames of ALL objects seen so far (detects cross-group interference).
- Matched accuracy: one-to-one cluster->object map fitted on TRAINING assignments (Hungarian), applied to test.
- ACC/BWT/Forgetting: from the matched-accuracy matrix R[stage, group] (Lopez-Paz & Ranzato, 2017).
- RET_ACC/RET_Forgetting: same matched map applied to the already-seen TRAINING frames of each group. This isolates forgetting (overwriting/competition) from cross-session generalisation.
- memory_floats: stored numbers (prototypes + counts + episode keys).
- legacy_group_ARI: the v1 protocol (ARI inside each two-object group); kept for comparability only.

## Limitations to disclose

- Synthetic data; validates mechanisms only.
