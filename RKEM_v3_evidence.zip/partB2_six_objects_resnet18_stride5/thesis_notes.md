# Part B2: CORe50 six_objects_resnet18_stride5 (test sessions 3, 7, 10)

**Status:** Measured on CORe50; hyperparameters selected on validation session only

## Protocol

- protocol: six_objects
- encoder: resnet18
- train_sessions: [1, 2, 4, 5, 6, 8, 9]
- val_sessions: [11]
- test_sessions: [3, 7, 10]
- frame_stride: 5
- max_frames: 60
- hflip_tta: True
- batch_size: 64
- num_workers: 2
- seeds: [11, 22, 33, 44, 55]
- tune_seeds: [11, 22, 33]
- stages: ((1, 2), (3, 4), (5, 6))
- tuned_v2: {'vpl': 'whiten', 'sigma_scale': 0.9, 'target_node_fraction': 0.02, 'rk': (0.5, 0.9, 0.5), 'merge_thr': 0.2, 'join_thr': 0.5, 'anchor': 0.2}
- tuned_v3: {'tau_stm': 0.2, 'merge_ep': 0.45, 'w_ep': 0.75, 'ep_sigma_scale': 0.5, 'tau_match': 0.6, 'margin': 0.1, 'join_ep': 0.7}
- v1_node_fraction: 0.05
- hyperparameters: {'sigma_scale': 0.9, 'target_node_fraction': 0.02, 'merge_thr': 0.2, 'join_thr': 0.5, 'tau_stm': 0.2, 'merge_ep': 0.45, 'w_ep': 0.75, 'ep_sigma_scale': 0.5, 'tau_match': 0.6, 'margin': 0.1, 'join_ep': 0.7}

## Final results (mean over runs)

| Variant | ACC | BWT | Forgetting | RET_ACC | RET_Forgetting | AUC_matched | ARI_seen | NMI_seen | HungarianAcc | legacy_group_ARI | prototypes | concepts | memory_floats |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A  v1 Baseline (original) | 0.257 | -0.046 | 0.078 | 0.182 | 0.025 | 0.262 | 0.182 | 0.403 | 0.319 | 0.139 | 200.000 | 200.000 | 102800.000 |
| A* v1 Baseline (tuned budget) | 0.304 | -0.034 | 0.065 | 0.210 | 0.040 | 0.307 | 0.208 | 0.392 | 0.355 | 0.168 | 97.400 | 97.400 | 50063.600 |
| B  v1 + Stability | 0.414 | -0.115 | 0.118 | 0.278 | 0.059 | 0.418 | 0.278 | 0.441 | 0.445 | 0.260 | 62.600 | 62.600 | 32176.400 |
| C  + VPL | 0.243 | -0.210 | 0.210 | 0.264 | 0.185 | 0.251 | 0.095 | 0.233 | 0.316 | 0.051 | 9.200 | 9.200 | 1196.000 |
| D  + RKLL two-timescale recurrence | 0.399 | -0.083 | 0.083 | 0.368 | 0.058 | 0.308 | 0.343 | 0.510 | 0.518 | 0.418 | 16.600 | 16.600 | 4282.800 |
| E  + EMCL anchors | 0.410 | 0.014 | -0.014 | 0.395 | 0.007 | 0.307 | 0.347 | 0.534 | 0.499 | 0.429 | 17.400 | 17.400 | 4489.200 |
| F  RKEM-Net v2 (full) | 0.446 | 0.014 | -0.014 | 0.396 | 0.007 | 0.372 | 0.347 | 0.534 | 0.499 | 0.429 | 17.400 | 17.000 | 4489.200 |
| G  v2 + generative replay | 0.440 | -0.003 | 0.003 | 0.393 | 0.009 | 0.373 | 0.341 | 0.523 | 0.497 | 0.416 | 17.600 | 17.200 | 4540.800 |
| L1 v2 - VPL | 0.520 | -0.114 | 0.116 | 0.322 | 0.073 | 0.547 | 0.402 | 0.574 | 0.543 | 0.390 | 28.400 | 20.800 | 29138.400 |
| L2 v2 - recurrence | 0.219 | -0.180 | 0.188 | 0.229 | 0.145 | 0.319 | 0.047 | 0.101 | 0.268 | 0.042 | 9.200 | 4.800 | 1196.000 |
| L3 v2 - anchors | 0.432 | -0.087 | 0.087 | 0.368 | 0.058 | 0.373 | 0.343 | 0.510 | 0.518 | 0.418 | 16.600 | 16.600 | 4282.800 |
| L4 v2 - concepts | 0.410 | 0.014 | -0.014 | 0.395 | 0.007 | 0.307 | 0.347 | 0.534 | 0.499 | 0.429 | 17.400 | 17.400 | 4489.200 |
| C1 v2 shuffled frames | 0.399 | -0.054 | 0.054 | 0.360 | 0.011 | 0.314 | 0.365 | 0.545 | 0.494 | 0.403 | 26.600 | 22.200 | 6862.800 |
| C2 v2 task-free (no boundaries) | 0.317 | -0.271 | 0.271 | 0.365 | 0.191 | 0.427 | 0.125 | 0.237 | 0.317 | 0.083 | 16.200 | 2.200 | 4179.600 |
| V3  RKEM-Net v3 (full) | 0.480 | -0.079 | 0.079 | 0.505 | 0.050 | 0.490 | 0.305 | 0.543 | 0.481 | 0.463 | 20.600 | 3.200 | 15008.800 |
| V3a v3 frame-level routing | 0.380 | -0.187 | 0.187 | 0.522 | 0.001 | 0.460 | 0.305 | 0.537 | 0.484 | 0.462 | 21.000 | 3.000 | 15265.800 |
| V3b v3 no margin gate | 0.480 | -0.079 | 0.079 | 0.505 | 0.050 | 0.490 | 0.305 | 0.543 | 0.481 | 0.463 | 20.600 | 3.200 | 15008.800 |
| V3c v3 no STM (ambiguous->LTM) | 0.167 | 0.000 | 0.000 | 0.167 | 0.000 | 0.306 | 0.000 | 0.000 | 0.167 | 0.000 | 17.400 | 1.000 | 8583.800 |
| V3d v3 no episode keys (w_ep=0) | 0.167 | 0.000 | 0.000 | 0.167 | 0.000 | 0.306 | 0.000 | 0.000 | 0.167 | 0.000 | 17.400 | 1.000 | 8583.800 |
| V3e v3 unlimited memory | 0.480 | -0.079 | 0.079 | 0.505 | 0.050 | 0.490 | 0.305 | 0.543 | 0.481 | 0.463 | 20.600 | 3.200 | 15008.800 |
| V3f v3 shuffled frames | 0.442 | -0.138 | 0.138 | 0.509 | 0.050 | 0.473 | 0.255 | 0.489 | 0.442 | 0.490 | 25.000 | 3.000 | 16036.800 |
| V3g v3 task-free (no boundaries) | 0.162 | -0.032 | 0.032 | 0.200 | 0.000 | 0.304 | 0.016 | 0.027 | 0.189 | 0.020 | 12.000 | 1.000 | 3855.000 |
| V31 v3.1 detector also inside given recordings | 0.426 | -0.118 | 0.118 | 0.520 | 0.026 | 0.417 | 0.243 | 0.418 | 0.468 | 0.394 | 20.000 | 5.400 | 18966.600 |
| V31f v3.1 shuffled frames | 0.388 | -0.251 | 0.251 | 0.450 | 0.104 | 0.399 | 0.329 | 0.400 | 0.461 | 0.279 | 63.000 | 34.800 | 101823.400 |
| V31g v3.1 task-free (no boundaries) | 0.435 | -0.124 | 0.124 | 0.523 | 0.026 | 0.437 | 0.251 | 0.405 | 0.470 | 0.392 | 20.600 | 5.600 | 18863.800 |

## Paired comparison vs tuned v1 baseline (stage-mean matched accuracy)

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.0451 |    0.0828 |      1 |   5 |       0.4375 |
| B  v1 + Stability                              |      0.1106 |    0.088  |      4 |   5 |       0.125  |
| C  + VPL                                       |     -0.0566 |    0.0972 |      1 |   5 |       0.3125 |
| C1 v2 shuffled frames                          |      0.007  |    0.0991 |      3 |   5 |       0.8125 |
| C2 v2 task-free (no boundaries)                |      0.12   |    0.0594 |      5 |   5 |       0.0625 |
| D  + RKLL two-timescale recurrence             |      0.001  |    0.1262 |      3 |   5 |       1      |
| E  + EMCL anchors                              |     -0.0003 |    0.1017 |      3 |   5 |       1      |
| F  RKEM-Net v2 (full)                          |      0.0651 |    0.0551 |      5 |   5 |       0.0625 |
| G  v2 + generative replay                      |      0.0659 |    0.057  |      5 |   5 |       0.0625 |
| L1 v2 - VPL                                    |      0.2394 |    0.0812 |      5 |   5 |       0.0625 |
| L2 v2 - recurrence                             |      0.0115 |    0.1055 |      2 |   5 |       1      |
| L3 v2 - anchors                                |      0.0652 |    0.0801 |      5 |   5 |       0.0625 |
| L4 v2 - concepts                               |     -0.0003 |    0.1017 |      3 |   5 |       1      |
| V3  RKEM-Net v3 (full)                         |      0.1827 |    0.0615 |      5 |   5 |       0.0625 |
| V31 v3.1 detector also inside given recordings |      0.11   |    0.0848 |      5 |   5 |       0.0625 |
| V31f v3.1 shuffled frames                      |      0.0912 |    0.0661 |      5 |   5 |       0.0625 |
| V31g v3.1 task-free (no boundaries)            |      0.1294 |    0.0708 |      5 |   5 |       0.0625 |
| V3a v3 frame-level routing                     |      0.1522 |    0.0642 |      5 |   5 |       0.0625 |
| V3b v3 no margin gate                          |      0.1827 |    0.0615 |      5 |   5 |       0.0625 |
| V3c v3 no STM (ambiguous->LTM)                 |     -0.0018 |    0.0623 |      2 |   5 |       1      |
| V3d v3 no episode keys (w_ep=0)                |     -0.0018 |    0.0623 |      2 |   5 |       1      |
| V3e v3 unlimited memory                        |      0.1827 |    0.0615 |      5 |   5 |       0.0625 |
| V3f v3 shuffled frames                         |      0.1658 |    0.0632 |      5 |   5 |       0.0625 |
| V3g v3 task-free (no boundaries)               |     -0.0034 |    0.0637 |      2 |   5 |       1      |

## Ablation: paired difference vs full v2 (negative = component helps)

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.1102 |    0.0544 |      0 |   5 |       0.0625 |
| A* v1 Baseline (tuned budget)                  |     -0.0651 |    0.0551 |      0 |   5 |       0.0625 |
| B  v1 + Stability                              |      0.0456 |    0.0417 |      4 |   5 |       0.125  |
| C  + VPL                                       |     -0.1216 |    0.085  |      0 |   5 |       0.0625 |
| C1 v2 shuffled frames                          |     -0.058  |    0.0664 |      2 |   5 |       0.3125 |
| C2 v2 task-free (no boundaries)                |      0.0549 |    0.0336 |      5 |   5 |       0.0625 |
| D  + RKLL two-timescale recurrence             |     -0.0641 |    0.1046 |      2 |   5 |       0.4375 |
| E  + EMCL anchors                              |     -0.0653 |    0.0877 |      0 |   5 |       0.25   |
| G  v2 + generative replay                      |      0.0008 |    0.0022 |      3 |   5 |       0.8125 |
| L1 v2 - VPL                                    |      0.1744 |    0.0399 |      5 |   5 |       0.0625 |
| L2 v2 - recurrence                             |     -0.0535 |    0.0565 |      1 |   5 |       0.125  |
| L3 v2 - anchors                                |      0.0001 |    0.0348 |      2 |   5 |       0.8125 |
| L4 v2 - concepts                               |     -0.0653 |    0.0877 |      0 |   5 |       0.25   |
| V3  RKEM-Net v3 (full)                         |      0.1177 |    0.0234 |      5 |   5 |       0.0625 |
| V31 v3.1 detector also inside given recordings |      0.0449 |    0.0691 |      3 |   5 |       0.3125 |
| V31f v3.1 shuffled frames                      |      0.0262 |    0.0379 |      3 |   5 |       0.3125 |
| V31g v3.1 task-free (no boundaries)            |      0.0643 |    0.0521 |      5 |   5 |       0.0625 |
| V3a v3 frame-level routing                     |      0.0871 |    0.0256 |      5 |   5 |       0.0625 |
| V3b v3 no margin gate                          |      0.1177 |    0.0234 |      5 |   5 |       0.0625 |
| V3c v3 no STM (ambiguous->LTM)                 |     -0.0669 |    0.022  |      0 |   5 |       0.0625 |
| V3d v3 no episode keys (w_ep=0)                |     -0.0669 |    0.022  |      0 |   5 |       0.0625 |
| V3e v3 unlimited memory                        |      0.1177 |    0.0234 |      5 |   5 |       0.0625 |
| V3f v3 shuffled frames                         |      0.1007 |    0.0225 |      5 |   5 |       0.0625 |
| V3g v3 task-free (no boundaries)               |     -0.0685 |    0.0221 |      0 |   5 |       0.0625 |

## v3_vs_v2_all_metrics

|                                           |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| ('AUC_matched', 'V3  RKEM-Net v3 (full)') |      0.1177 |    0.0234 |      5 |   5 |       0.0625 |
| ('ARI_seen', 'V3  RKEM-Net v3 (full)')    |     -0.0426 |    0.0273 |      0 |   5 |       0.0625 |
| ('RET_ACC', 'V3  RKEM-Net v3 (full)')     |      0.1091 |    0.018  |      5 |   5 |       0.0625 |
| ('RET_F', 'V3  RKEM-Net v3 (full)')       |      0.0425 |    0.1059 |      1 |   5 |       0.875  |
| ('BWT', 'V3  RKEM-Net v3 (full)')         |     -0.0933 |    0.1103 |      1 |   5 |       0.125  |

## v3_ablations

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.2278 |    0.0601 |      0 |   5 |       0.0625 |
| A* v1 Baseline (tuned budget)                  |     -0.1827 |    0.0615 |      0 |   5 |       0.0625 |
| B  v1 + Stability                              |     -0.0721 |    0.0531 |      0 |   5 |       0.0625 |
| C  + VPL                                       |     -0.2393 |    0.0715 |      0 |   5 |       0.0625 |
| C1 v2 shuffled frames                          |     -0.1757 |    0.0573 |      0 |   5 |       0.0625 |
| C2 v2 task-free (no boundaries)                |     -0.0627 |    0.0269 |      0 |   5 |       0.0625 |
| D  + RKLL two-timescale recurrence             |     -0.1818 |    0.1029 |      0 |   5 |       0.0625 |
| E  + EMCL anchors                              |     -0.183  |    0.0918 |      0 |   5 |       0.0625 |
| F  RKEM-Net v2 (full)                          |     -0.1177 |    0.0234 |      0 |   5 |       0.0625 |
| G  v2 + generative replay                      |     -0.1169 |    0.0236 |      0 |   5 |       0.0625 |
| L1 v2 - VPL                                    |      0.0567 |    0.0499 |      5 |   5 |       0.0625 |
| L2 v2 - recurrence                             |     -0.1712 |    0.0553 |      0 |   5 |       0.0625 |
| L3 v2 - anchors                                |     -0.1176 |    0.0264 |      0 |   5 |       0.0625 |
| L4 v2 - concepts                               |     -0.183  |    0.0918 |      0 |   5 |       0.0625 |
| V31 v3.1 detector also inside given recordings |     -0.0727 |    0.0516 |      1 |   5 |       0.125  |
| V31f v3.1 shuffled frames                      |     -0.0915 |    0.0375 |      0 |   5 |       0.0625 |
| V31g v3.1 task-free (no boundaries)            |     -0.0534 |    0.043  |      1 |   5 |       0.125  |
| V3a v3 frame-level routing                     |     -0.0306 |    0.0059 |      0 |   5 |       0.0625 |
| V3b v3 no margin gate                          |      0      |    0      |      0 |   5 |       1      |
| V3c v3 no STM (ambiguous->LTM)                 |     -0.1846 |    0.0036 |      0 |   5 |       0.0625 |
| V3d v3 no episode keys (w_ep=0)                |     -0.1846 |    0.0036 |      0 |   5 |       0.0625 |
| V3e v3 unlimited memory                        |      0      |    0      |      0 |   5 |       1      |
| V3f v3 shuffled frames                         |     -0.017  |    0.004  |      0 |   5 |       0.0625 |
| V3g v3 task-free (no boundaries)               |     -0.1862 |    0.0037 |      0 |   5 |       0.0625 |

## retention_forgetting_vs_v1

| variant                                        |   mean_gain |   sd_gain |   wins |   n |   wilcoxon_p |
|:-----------------------------------------------|------------:|----------:|-------:|----:|-------------:|
| A  v1 Baseline (original)                      |     -0.0148 |    0.0431 |      2 |   5 |       0.625  |
| B  v1 + Stability                              |      0.0185 |    0.042  |      3 |   5 |       0.4375 |
| C  + VPL                                       |      0.1443 |    0.0435 |      5 |   5 |       0.0625 |
| C1 v2 shuffled frames                          |     -0.0294 |    0.0338 |      1 |   5 |       0.1875 |
| C2 v2 task-free (no boundaries)                |      0.1512 |    0.1005 |      4 |   5 |       0.125  |
| D  + RKLL two-timescale recurrence             |      0.0173 |    0.0526 |      3 |   5 |       0.625  |
| E  + EMCL anchors                              |     -0.0331 |    0.0461 |      1 |   5 |       0.3125 |
| F  RKEM-Net v2 (full)                          |     -0.0331 |    0.0461 |      1 |   5 |       0.3125 |
| G  v2 + generative replay                      |     -0.0313 |    0.0472 |      1 |   5 |       0.3125 |
| L1 v2 - VPL                                    |      0.0331 |    0.0357 |      4 |   5 |       0.125  |
| L2 v2 - recurrence                             |      0.1049 |    0.1092 |      4 |   5 |       0.125  |
| L3 v2 - anchors                                |      0.0173 |    0.0526 |      3 |   5 |       0.625  |
| L4 v2 - concepts                               |     -0.0331 |    0.0461 |      1 |   5 |       0.3125 |
| V3  RKEM-Net v3 (full)                         |      0.0094 |    0.1141 |      2 |   5 |       1      |
| V31 v3.1 detector also inside given recordings |     -0.0146 |    0.0573 |      2 |   5 |       0.625  |
| V31f v3.1 shuffled frames                      |      0.064  |    0.0522 |      5 |   5 |       0.0625 |
| V31g v3.1 task-free (no boundaries)            |     -0.0144 |    0.0509 |      2 |   5 |       0.8125 |
| V3a v3 frame-level routing                     |     -0.0392 |    0.0407 |      1 |   5 |       0.1875 |
| V3b v3 no margin gate                          |      0.0094 |    0.1141 |      2 |   5 |       1      |
| V3c v3 no STM (ambiguous->LTM)                 |     -0.0402 |    0.041  |      1 |   5 |       0.1875 |
| V3d v3 no episode keys (w_ep=0)                |     -0.0402 |    0.041  |      1 |   5 |       0.1875 |
| V3e v3 unlimited memory                        |      0.0094 |    0.1141 |      2 |   5 |       1      |
| V3f v3 shuffled frames                         |      0.0098 |    0.1459 |      1 |   5 |       0.625  |
| V3g v3 task-free (no boundaries)               |     -0.0402 |    0.041  |      1 |   5 |       0.1875 |

## Offline (non-continual) reference

| features   |   ARI_seen |   NMI_seen |   HungarianAcc_seen |   MatchedAcc_seen |   ProbeAcc_seen |   supervised_1NN_acc |
|:-----------|-----------:|-----------:|--------------------:|------------------:|----------------:|---------------------:|
| none       |      0.219 |      0.309 |               0.437 |             0.421 |           0.425 |                0.694 |
| center     |      0.217 |      0.303 |               0.435 |             0.429 |           0.438 |                0.689 |
| whiten     |      0.277 |      0.421 |               0.506 |             0.506 |           0.506 |                0.63  |

## Metric definitions

- ARI/NMI_seen: partition agreement on test frames of ALL objects seen so far (detects cross-group interference).
- Matched accuracy: one-to-one cluster->object map fitted on TRAINING assignments (Hungarian), applied to test.
- ACC/BWT/Forgetting: from the matched-accuracy matrix R[stage, group] (Lopez-Paz & Ranzato, 2017).
- RET_ACC/RET_Forgetting: same matched map applied to the already-seen TRAINING frames of each group. This isolates forgetting (overwriting/competition) from cross-session generalisation.
- memory_floats: stored numbers (prototypes + counts + episode keys).
- legacy_group_ARI: the v1 protocol (ARI inside each two-object group); kept for comparability only.

## Limitations to disclose

- Frozen encoder: forgetting is measured in the prototype/concept layer.
- The five orders share the same images (recording order randomised).
- Task-free controls concatenate recordings; real streams may have softer boundaries.
- Matched/probe maps use training labels after learning, for evaluation only.
